def is_pangram(s):
    alphabet = set("abcdefghijklmnopqrstuvwxyz")
    if set(s.lower()) == alphabet:
        print("Its pangram")
    else:
        print('Not a Pangram')
    return 
s=input("enter string : ")
result=is_pangram(s)