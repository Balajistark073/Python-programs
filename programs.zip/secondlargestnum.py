arr=[12,34,56,78,23,90,5678,1222,34,5678]
seta=set(arr)
lista=list(seta)
lista.sort()
print(lista[-2])