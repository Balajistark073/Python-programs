str1=input("enter string: ")
str1list=str1.split()
revstr=""
for i in str1list[::-1]:
    revstr+=i+" "
print(revstr)


