str1=input("enter a string: ")
print(str1.partition('e'))
