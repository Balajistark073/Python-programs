arr=[1664,87,45,45,2222,1664,333,999,1234,999]
set1=set(arr)
print(set1)
soretdset=sorted(set1)
print(soretdset)