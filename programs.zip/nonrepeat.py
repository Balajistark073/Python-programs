from collections import Counter
def nonrepeat(line):
    freqcount=Counter(line)
    for i in line:
        if freqcount[i]==1:
            print(i,end=' ')
line=input("Enter string: ")
nonrepeat(line)
        
    
